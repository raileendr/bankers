# Banker's Algorithm - Project 3 - CPSC 351
In this assignment, I created a solution for the banker's algorithm project from section 8.6.3 (Banker’s Algorithm) in
the 10th edition of Silberschatz (Operating System Concepts), or the 8th or 9th ed. of Stallings (Operating Systems: Internals
and Design Principles). My solution is in C++.
